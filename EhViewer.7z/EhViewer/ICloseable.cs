﻿namespace EhViewer
{
    public interface ICloseable
    {
        void Close();
    }
}
